<?php
/* Silence is Golden */
